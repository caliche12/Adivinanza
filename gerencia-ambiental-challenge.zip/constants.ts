import { Riddle } from './types';

export const RIDDLES: Riddle[] = [
  {
    id: 1,
    question: "Soy añoso y fuerte, río resiliente,\ncon metales pesados manché mi corriente.\nUn incidente trágico fue industrial,\npara mis bebedores, un daño fatal.\nTuvieron crisis, mas con persistencia,\nrecuperé limpia mi antigua esencia.\n¿Quién soy?",
    options: [
      { id: 'china', label: 'China' },
      { id: 'pamplona', label: 'Pamplona, Norte de Santander' },
      { id: 'amazonas', label: 'Región Amazónica' },
    ],
    correctAnswer: 'china',
    explanation: "Esta adivinanza hace referencia a la contaminación industrial en los ríos de China (ej. Río Songhua), donde metales pesados causaron crisis de agua potable, requiriendo grandes esfuerzos de limpieza.",
    factSource: "Contexto: Crisis hídrica y contaminación industrial"
  },
  {
    id: 2,
    question: "Soy los alvéolos de la naturaleza,\nque se van perdiendo con gran tristeza.\nOfrecen pagos por mi cuidado,\npero por la violencia todavía se presenta.\nLas llamas y la codicia me acechan con destreza.\n¿Dónde estoy?",
    options: [
      { id: 'china', label: 'China' },
      { id: 'pamplona', label: 'Pamplona, Norte de Santander' },
      { id: 'amazonas', label: 'Región Amazónica' },
    ],
    correctAnswer: 'amazonas',
    explanation: "Se refiere a la selva amazónica ('alvéolos' o pulmones). Menciona los incentivos económicos (Pagos por Servicios Ambientales) que luchan contra la deforestación, incendios y conflictos en la región.",
    factSource: "Contexto: Deforestación y Pagos por Servicios Ambientales"
  },
  {
    id: 3,
    question: "Era mi ambiente tóxico y nocivo,\naunque me han limpiado, sigo siendo el más activo.\nSoy el que más emite, no hay quien me iguale,\nhago casi todo, mi poder es notable.\nSoy bastante ambicioso y soy muy grande.\n¿Qué lugar soy?",
    options: [
      { id: 'china', label: 'China' },
      { id: 'pamplona', label: 'Pamplona, Norte de Santander' },
      { id: 'amazonas', label: 'Región Amazónica' },
    ],
    correctAnswer: 'china',
    explanation: "China ha mejorado su calidad del aire recientemente, pero sigue siendo el mayor emisor global de gases de efecto invernadero debido a su enorme capacidad industrial y ambición económica.",
    factSource: "Contexto: Emisiones globales y desarrollo industrial"
  },
  {
    id: 4,
    question: "Dependen de mí líquido, mas no hay cuidado,\nproponen acciones, pero soy ignorado.\nCerca del epicentro me encuentro,\ndonde los movimientos bruscos siento.\n¿Me encuentras?",
    options: [
      { id: 'china', label: 'China' },
      { id: 'pamplona', label: 'Pamplona, Norte de Santander' },
      { id: 'amazonas', label: 'Región Amazónica' },
    ],
    correctAnswer: 'pamplona',
    explanation: "Alude al abandono de fuentes hídricas (Río Pamplonita) a pesar de su importancia vital. La referencia al 'epicentro' señala la ubicación geográfica cerca de zonas de alta actividad sísmica (Nido de Bucaramanga).",
    factSource: "Contexto: Gestión ambiental local y geografía"
  }
];