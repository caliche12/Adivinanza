import React, { useState } from 'react';
import { GameState, LocationId } from './types';
import { RIDDLES } from './constants';
import { Button } from './components/Button';
import { QuizCard } from './components/QuizCard';
import { FeedbackModal } from './components/FeedbackModal';
import { Leaf, Trees, Award, RefreshCcw } from 'lucide-react';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    status: 'welcome',
    currentQuestionIndex: 0,
    score: 0,
    answers: []
  });

  const [selectedAnswer, setSelectedAnswer] = useState<LocationId | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const startGame = () => {
    setGameState({
      status: 'playing',
      currentQuestionIndex: 0,
      score: 0,
      answers: []
    });
    setSelectedAnswer(null);
    setShowFeedback(false);
  };

  const handleAnswer = (answer: LocationId) => {
    const currentRiddle = RIDDLES[gameState.currentQuestionIndex];
    const isCorrect = answer === currentRiddle.correctAnswer;
    
    setSelectedAnswer(answer);
    setShowFeedback(true);

    // Update score immediately for tracking, but state update happens on next
    if (isCorrect) {
      setGameState(prev => ({
        ...prev,
        score: prev.score + 1
      }));
    }
  };

  const handleNextQuestion = () => {
    setShowFeedback(false);
    setSelectedAnswer(null);

    const nextIndex = gameState.currentQuestionIndex + 1;
    
    if (nextIndex < RIDDLES.length) {
      setGameState(prev => ({
        ...prev,
        currentQuestionIndex: nextIndex
      }));
    } else {
      setGameState(prev => ({
        ...prev,
        status: 'finished'
      }));
    }
  };

  const currentRiddle = RIDDLES[gameState.currentQuestionIndex];
  const progressPercentage = ((gameState.currentQuestionIndex) / RIDDLES.length) * 100;

  return (
    <div className="min-h-screen bg-eco-cream relative overflow-hidden font-nunito selection:bg-eco-green selection:text-white">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-eco-green/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-eco-dark-green/10 rounded-full blur-3xl translate-x-1/3 translate-y-1/3 pointer-events-none" />

      <div className="max-w-4xl mx-auto px-6 py-8 relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="flex justify-between items-center mb-12">
          <div className="flex items-center gap-2">
            <div className="bg-eco-dark-green p-2 rounded-lg text-white">
              <Trees size={24} />
            </div>
            <h1 className="font-fredoka text-xl md:text-2xl font-bold text-eco-text">
              Gerencia Ambiental
            </h1>
          </div>
          
          {gameState.status === 'playing' && (
            <div className="bg-white px-4 py-2 rounded-full shadow-sm border border-stone-100 flex items-center gap-2">
              <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Progreso</span>
              <span className="font-bold text-eco-dark-green">
                {gameState.currentQuestionIndex + 1}/{RIDDLES.length}
              </span>
            </div>
          )}
        </header>

        {/* Main Content */}
        <main className="flex-grow flex flex-col justify-center items-center">
          
          {gameState.status === 'welcome' && (
            <div className="text-center max-w-xl animate-fade-in-up">
              <div className="mb-8 inline-block relative">
                <div className="absolute inset-0 bg-eco-green/20 rounded-full blur-xl transform scale-110"></div>
                <Leaf className="w-24 h-24 text-eco-green relative z-10 mx-auto" strokeWidth={1.5} />
              </div>
              <h1 className="text-4xl md:text-5xl font-fredoka font-bold text-eco-text mb-6">
                El Desafío Ambiental
              </h1>
              <p className="text-lg text-stone-600 mb-10 leading-relaxed">
                Pon a prueba tu conocimiento sobre las problemáticas de <span className="font-bold text-eco-dark-green">Pamplona</span>, <span className="font-bold text-eco-dark-green">China</span> y el <span className="font-bold text-eco-dark-green">Amazonas</span>. Resuelve 4 adivinanzas difíciles basadas en datos reales.
              </p>
              <Button onClick={startGame} className="text-lg px-12 shadow-xl shadow-eco-green/20">
                Comenzar Desafío
              </Button>
            </div>
          )}

          {gameState.status === 'playing' && (
            <div className="w-full">
              {/* Progress Bar */}
              <div className="w-full h-2 bg-stone-200 rounded-full mb-8 overflow-hidden max-w-2xl mx-auto">
                <div 
                  className="h-full bg-eco-green transition-all duration-500 ease-out rounded-full"
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>

              <QuizCard 
                riddle={currentRiddle}
                onAnswer={handleAnswer}
                isAnswering={showFeedback}
              />
            </div>
          )}

          {gameState.status === 'finished' && (
            <div className="text-center max-w-lg w-full bg-white p-8 md:p-12 rounded-[2.5rem] shadow-xl animate-scale-up">
              <div className="mb-6 flex justify-center">
                <div className="bg-yellow-100 p-4 rounded-full text-yellow-600">
                  <Award size={48} />
                </div>
              </div>
              
              <h2 className="text-3xl font-fredoka font-bold text-eco-text mb-2">
                ¡Desafío Completado!
              </h2>
              
              <div className="text-6xl font-black text-eco-green mb-2 font-fredoka">
                {gameState.score}/{RIDDLES.length}
              </div>
              
              <p className="text-stone-500 mb-8 font-medium">
                {gameState.score === RIDDLES.length 
                  ? "¡Excelente! Dominas el tema a la perfección." 
                  : gameState.score >= 2 
                    ? "Buen trabajo, pero hay detalles por repasar." 
                    : "Te recomiendo revisar el documento nuevamente."}
              </p>

              <div className="bg-stone-50 rounded-2xl p-6 mb-8 text-left border border-stone-100">
                <h3 className="font-bold text-eco-text mb-4">Resumen de Datos Clave:</h3>
                <ul className="space-y-3 text-sm text-stone-600">
                  <li className="flex gap-2">
                    <span className="text-eco-green">•</span>
                    <span>China: Líder en renovables pero depende 56% del carbón.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-eco-green">•</span>
                    <span>Amazonas: Deforestación subió 74% en 2024.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-eco-green">•</span>
                    <span>Pamplona: Sin avances en PTAR al primer semestre de 2025.</span>
                  </li>
                </ul>
              </div>

              <Button onClick={startGame} variant="secondary" fullWidth>
                <div className="flex items-center justify-center gap-2">
                  <RefreshCcw size={18} /> Jugar de Nuevo
                </div>
              </Button>
            </div>
          )}
        </main>
      </div>

      {/* Feedback Modal */}
      {showFeedback && currentRiddle && (
        <FeedbackModal 
          riddle={currentRiddle}
          selectedAnswer={selectedAnswer}
          onNext={handleNextQuestion}
        />
      )}
    </div>
  );
};

export default App;