import React from 'react';
import { Riddle, LocationId } from '../types';
import { Leaf, MapPin, Globe2 } from 'lucide-react';

interface QuizCardProps {
  riddle: Riddle;
  onAnswer: (locationId: LocationId) => void;
  isAnswering: boolean;
}

export const QuizCard: React.FC<QuizCardProps> = ({ riddle, onAnswer, isAnswering }) => {
  const getIcon = (id: LocationId) => {
    switch (id) {
      case 'amazonas': return <Leaf className="w-5 h-5" />;
      case 'pamplona': return <MapPin className="w-5 h-5" />;
      case 'china': return <Globe2 className="w-5 h-5" />;
    }
  };

  return (
    <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-stone-100 max-w-2xl w-full mx-auto animate-fade-in-up">
      <div className="mb-6 flex items-center gap-2 text-eco-dark-green opacity-70 font-bold uppercase tracking-wider text-sm">
        <span>Adivinanza #{riddle.id}</span>
      </div>
      
      <h2 className="text-2xl md:text-3xl font-fredoka text-eco-text leading-relaxed mb-10 whitespace-pre-line">
        "{riddle.question}"
      </h2>

      <div className="grid gap-4">
        {riddle.options.map((option) => (
          <button
            key={option.id}
            onClick={() => onAnswer(option.id)}
            disabled={isAnswering}
            className={`
              group relative overflow-hidden p-5 rounded-xl border-2 text-left transition-all duration-300
              ${isAnswering ? 'cursor-not-allowed opacity-50' : 'hover:border-eco-green hover:bg-eco-accent/30 border-stone-100 bg-stone-50'}
            `}
          >
            <div className="flex items-center gap-4 relative z-10">
              <div className={`
                p-3 rounded-full 
                ${isAnswering ? 'bg-stone-200 text-stone-400' : 'bg-white text-eco-dark-green shadow-sm group-hover:scale-110 transition-transform duration-300'}
              `}>
                {getIcon(option.id)}
              </div>
              <span className="font-nunito font-bold text-lg text-eco-text">
                {option.label}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};