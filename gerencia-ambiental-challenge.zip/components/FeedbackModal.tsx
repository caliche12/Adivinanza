import React from 'react';
import { Riddle, LocationId } from '../types';
import { CheckCircle2, XCircle, ArrowRight } from 'lucide-react';
import { Button } from './Button';

interface FeedbackModalProps {
  riddle: Riddle;
  selectedAnswer: LocationId | null;
  onNext: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ riddle, selectedAnswer, onNext }) => {
  if (!selectedAnswer) return null;

  const isCorrect = selectedAnswer === riddle.correctAnswer;
  const correctOptionLabel = riddle.options.find(o => o.id === riddle.correctAnswer)?.label;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl transform transition-all animate-scale-up">
        <div className="flex flex-col items-center text-center mb-6">
          <div className={`rounded-full p-4 mb-4 ${isCorrect ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-500'}`}>
            {isCorrect ? <CheckCircle2 size={48} /> : <XCircle size={48} />}
          </div>
          
          <h3 className={`text-2xl font-fredoka font-bold mb-2 ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
            {isCorrect ? '¡Correcto!' : 'Incorrecto'}
          </h3>
          
          <p className="text-stone-500 font-nunito mb-6">
            {isCorrect 
              ? 'Has identificado la problemática correctamente.' 
              : `La respuesta correcta era: ${correctOptionLabel}`}
          </p>

          <div className="bg-eco-accent/40 rounded-xl p-5 text-left w-full border border-eco-green/20">
            <p className="text-sm font-bold text-eco-dark-green mb-2 uppercase tracking-wide">Explicación del Documento:</p>
            <p className="text-eco-text font-nunito leading-relaxed">
              {riddle.explanation}
            </p>
            <p className="text-xs text-stone-400 mt-3 italic">
              Fuente: {riddle.factSource}
            </p>
          </div>
        </div>

        <Button onClick={onNext} fullWidth>
          <div className="flex items-center justify-center gap-2">
            Siguiente Desafío <ArrowRight size={18} />
          </div>
        </Button>
      </div>
    </div>
  );
};