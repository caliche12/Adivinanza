import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "py-3 px-6 rounded-2xl font-nunito font-bold transition-all duration-300 transform hover:scale-[1.02] active:scale-95 shadow-sm";
  
  const variants = {
    primary: "bg-eco-green text-white hover:bg-[#92b54b] shadow-eco-green/30",
    secondary: "bg-eco-dark-green text-white hover:bg-[#3d755f] shadow-eco-dark-green/30",
    outline: "border-2 border-eco-dark-green text-eco-dark-green hover:bg-eco-dark-green hover:text-white"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};