export type LocationId = 'pamplona' | 'china' | 'amazonas';

export interface Riddle {
  id: number;
  question: string;
  options: { id: LocationId; label: string }[];
  correctAnswer: LocationId;
  explanation: string;
  factSource: string;
}

export interface GameState {
  status: 'welcome' | 'playing' | 'finished';
  currentQuestionIndex: number;
  score: number;
  answers: { questionId: number; correct: boolean }[];
}